# OpenGTS image based on phusion baseimage

docker-compose.yml file is included in git repository as example to run the application

