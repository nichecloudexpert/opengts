#!/bin/bash
exec /sbin/setuser opengts $CATALINA_HOME/bin/catalina.sh run


